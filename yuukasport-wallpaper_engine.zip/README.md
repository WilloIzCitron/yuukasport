
# Overview
This is a live wallpaper of Yuuka (Track ver.). because lack of permission, they can took down either contribute if can!
this can be supported on Lively(untested)

# How to 
If you want to develop and contribute in this project you can do this below:
## Build
TODO

# Known Issues
Warning! this project has many bugs

This is the issue tables below:
|  No |  Issues |  Issue No |
|---|---|---|
|  1 | After Headpatting, Blush can't disappear  |   |
| 2  |  Intro has 2 segments were splited |   |
| 3  |  Inaccurate hitbox |   |

# Credits
- [Fully Interactive Blue Archive L2D Mini-Collection](https://steamcommunity.com/sharedfiles/filedetails/?id=2956165539) by Xenon257R 

Disclaimer (Please Read): 
- This suite is a fan-made project inspired by Blue Archive and not directly affiliated with it. Copyright remains with the developer and publisher of Blue Archive: Nexon, NAT GAMES and Yostar.
- This repository has fully forked from Xenon257R, including codes and assets

